#!/usr/bin/python3
# -*- coding: utf-8 -*-
# version v.0.3b
# https://en.wikipedia.org/wiki/Shebang_(Unix) #!/usr/bin/env python3\
import sys,os,re,math;
from array import *
#os.pathos.getcwd()
#os.path.normpath(path)
i=0;

#def linecount_1(  ):
#    return len(open('nuc').readlines(  ))

def join_strs_better(strs):
    return ' '.join(strs)
    

def mapcount(filename):
    f = open(filename, "r+")
    buf = mmap.mmap(f.fileno(), 0)
    lines = 0
    readline = buf.readline
    while readline():
        lines += 1
    return lines

def simplecount(filename):
    lines = 0
    for line in open(filename):
        lines += 1
    return lines

def bufcount(filename):
    f = open(filename)                  
    lines = 0
    buf_size = 1024 * 1024
    read_f = f.read # loop optimization

    buf = read_f(buf_size)
    while buf:
        lines += buf.count('\n')
        buf = read_f(buf_size)

    return lines

def opcount(fname):
    with open(fname) as f:
        for i, l in enumerate(f):
            pass
    return i + 1
    
# Returns True if End-Of-File is reached
def EOF1(f):
    current_pos = f.tell()
    file_size = os.fstat(f.fileno()).st_size
    return current_pos >= file_size
    
def strToList(st):
    return list(st.split("  "))
    
    
pdir=''.join([os.getcwd(),"/DebianISO/install_ext/install/pii2.sh"]);
#print(pdir);
##
# "x" - Create - will create a file, returns an error if the file exist
# "r" - Read - Default value. Opens a file for reading, error if the file does not exist
# "a" - Append - Opens a file for appending, creates the file if it does not exist
# "w" - Write - Opens a file for writing, creates the file if it does not exist
# "x" - Create - Creates the specified file, returns an error if the file exists
# In addition you can specify if the file should be handled as binary or text mode
# "t" - Text - Default value. Text mode
if not (os.path.exists(pdir)):
    print("The file does not exist");
    exit;

with open(pdir,"rt") as fpii2:
    linep = fpii2.readlines();
fpii2.close();
j=0;
if(str(''.join(re.findall('^#!\/bin\/(.*).*', linep[j])).strip())=="bash"):
        print("bash!")
else:
        print("Error: Unknown shell!")
j=1;k=0;
content=[""]*int(len(linep)/6);
#for k in range(0,len(linep)): content[0]="";
#h1
#==================

#h2
#------------------

#h3
#~~~~~~~~~~~~~~~~~~

#h4
""""""""""""""""""

for i in linep:
    #linep[j] = re.sub('\n', '', linep[j])
    if ((''.join(re.findall("^#", linep[j])))=="#"):
        s0=''.join(re.findall("#\t\t\t(\d+\t+[a-zA-Z/_\-&><=$%\[\]* ]*)", linep[j]));
        s1=''.join(re.findall("#\t\t\t(\d.\d+\t+[a-zA-Z/_\-&><=$%\[\]* ]*)", linep[j]));
        s2=''.join(re.findall("#\t\t\t(\d.\d.\d+\t+[a-zA-Z/_\-&><=$%\[\]* ]*)", linep[j]));
    if(s0!=""):
        h1=''.join(['=']*len(s0));
        content[k] = strToList("{0}\n{1}\n".format(s0,h1));
        #print(str(["="]*len(h1)));
        #content[k+1] = strToList("{0}\n".format(''.join(h1)));
        k+=1;
    if(s1!=""):
        h2=''.join(['-']*len(s1));
        content[k] = strToList("\t{0}\n{1}\n".format(s1,h2));
        #print(str(["-"]*len(h2)));
        #content[k+1] = strToList("{0}\n".format(''.join(h2)));
        k+=1;
    if(s2!=""):
        h3=''.join(["~"]*len(s2));
        content[k] = strToList("\t\t{0}\n{1}\n".format(s2,h3));
        k+=1;
        
    linep[j] = re.sub('#<--!|#!-->', '', linep[j]);
    #if (''.join(re.findall("#\t\t\t(\d.\d.\d\.+.*)$", linep[j]))!=""):
    #print(''.join(re.findall("#\t\t\t\d.\d.(\d.\d.+.*)", linep[j])));
    j+=1;
    if(j>=len(linep)):
        break;
#print(re.sub("\t", " ",linep[j]));
#        print("yes");
print("_______________")
print("_______________")



#print(re.findall("#\t\t\t(\d.\d+\t+[a-zA-Z/_\-& ]*)", linep[20]))
#print(re.findall("#\t\t\t(\d.\d.\d+\t+[a-zA-Z/_\-& ]*)", linep[193]))
#str = re.findall("#\t\t\t(.*)$", linep[22])
#str1 = re.sub("\t", " ",linep[22])
#print(content)
print(content)

j=0;
pdir=''.join([os.getcwd(),"/out_content.sh"]);
with open(pdir,"wt") as fpii2:
    for i in content:
        #s0=''.join(content[j]);
        fpii2.write(''.join(content[j]));
        #print(content[j])
        j=j+1;
fpii2.close();


print("_____________________________________________")
print("_____________________________________________")
print("_____________________________________________")
print("_____________________________________________")

#MatPOS = [][]
#w, h = 5, 5
#MatPOS = [[0 for x in range(w)] for y in range(h)] 

#linep.clear();
#content.clear();

with open(pdir,"rt") as fpii2:
    linep = fpii2.readlines();
fpii2.close();
j=0;
if(str(''.join(re.findall('^#!\/bin\/(.*).*', linep[j])).strip())=="bash"):
        print("bash!")
else:
        print("Error: Unknown shell!")
j=1;k=0;
POS_0=0;
POS_END=0;
trig_search_code=0;

POS_LIST=[""]*int(len(linep)+0.3*len(linep));
#POS_LIST[i]="# pos_c_0 pos_c_end"
#POS_LIST[i]="$ pos_d_0 pos_d_end"
#
#str.find(sub[, start[, end]])
#Возвращает наименьший индекс, по которому обнаруживается начало указанной подстроки в исходной.
#sub : Подстрока, начальный индекс размещения которой требуется определить.
#start=0 : Индекс начала среза в исходной строке, в котором требуется отыскать подстроку.
#end=None : Индекс конца среза в исходной строке, в котором требуется отыскать подстроку.
#Если подстрока не найдена, возвращает −1.

    #trig_search_code=0;
    #linep[j] = re.sub('\n', '', linep[j])

for i in linep:
#   search comment #
    if ((''.join(re.findall("^#", linep[j])))=="#"):
        trig_search_code=1;
    if(trig_search_code == 1):
        POS_0=j;
        trig_search_code=0;
        #s0=''.join(re.findall("#\t\t\t(\d+\t+[a-zA-Z/_\-&><=$%\[\]* ]*)", linep[j]));
        #s1=''.join(re.findall("#\t\t\t(\d.\d+\t+[a-zA-Z/_\-&><=$%\[\]* ]*)", linep[j]));
        #s2=''.join(re.findall("#\t\t\t(\d.\d.\d+\t+[a-zA-Z/_\-&><=$%\[\]* ]*)", linep[j]));
        #POS_LIST[j] = strToList("# {0} {1}\n".format(''.join(h2)));
        #if(s0!=""):
        #    h1=''.join(['=']*len(s0));
        #    content[k] = strToList("{0}\n{1}\n".format(s0,h1));
        #print(str(["="]*len(h1)));
        #content[k+1] = strToList("{0}\n".format(''.join(h1)));
        #    k+=1;
        #if(s1!=""):
        #    h2=''.join(['-']*len(s1));
        #    content[k] = strToList("\t{0}\n{1}\n".format(s1,h2));
            #print(str(["-"]*len(h2)));
            #content[k+1] = strToList("{0}\n".format(''.join(h2)));
        #    k+=1;
        #if(s2!=""):
        #    h3=''.join(["~"]*len(s2));
        #    content[k] = strToList("\t\t{0}\n{1}\n".format(s2,h3));
        #    k+=1;
        POS_END=j;
    else:
        trig_search_code=2;
    if(trig_search_code == 2):
        POS_LIST[k]=strToList("#{0}{1}".format(POS_0,POS_END));
        k+=1;
        trig_search_code=0;
    if ((''.join(re.findall("^\"\"", linep[j])))==""):
        POS_0=j;
        trig_search_code=3;
    if(trig_search_code == 3):
       POS_0=j;
       trig_search_code=0;
    else:
       trig_search_code=1;
    if(trig_search_code == 1):
        POS_LIST[k]=strToList("${0}{1}".format(POS_0,POS_END));
        k+=1;
        trig_search_code=0;
    #linep[j] = re.sub('#<--!|#!-->', '', linep[j]);
    #if (''.join(re.findall("#\t\t\t(\d.\d.\d\.+.*)$", linep[j]))!=""):
    #print(''.join(re.findall("#\t\t\t\d.\d.(\d.\d.+.*)", linep[j])));
    j+=1;
    if(j>=len(linep)):
        break;

print(POS_LIST)
#.. code-block:: bash
#   :caption: EXT:site_package/Configuration/TCA/Overrides/sys_template.php

#   /**
#    * Add default TypoScript (constants and setup)
#    */
#   \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile(
#       'site_package',
#       'Configuration/TypoScript',
#       'Site Package'
#   );




#linep[16]=re.sub('\n', ' ',str)

#print(re.findall("#\t\t\t(.*)$", linep[16]))
#print(re.findall("#\t\t\t(.*)$", linep[17]))

#print(''.join(re.findall("#\t\t\t(.*)$", linep[16])));

#print(re.findall("^#<--!\(.*\)$", linep[4]));    

#rint(linep[2])
print(" ");
print(" ");
#p = re.search('\bclass\b')
#______SEARCH Commentary pii2.sh______
#
# 1) poisk #<--!

re.purge();


exit;













#for filename in os.listdir(directory):
#    if filename.endswith(".txt"):
#        f = open(filename)
#        lines = f.read()
#        print (lines[10])
#        continue
#    else:
#    continue

#fpii2 = open(pdir,"rwt")
#linep = ['']*os.fstat(fpii2.fileno()).st_size
#print(fpii2.readlines());
#fpii2.seek(0);
#with open("sample.txt", "r") as a_file:
