#!/usr/bin/python3
# -*- coding: utf-8 -*-
# version v.0.2a
# https://en.wikipedia.org/wiki/Shebang_(Unix) #!/usr/bin/env python3\
import sys,os,re,math;
from array import *
#os.pathos.getcwd()
#os.path.normpath(path)
i=0;
#def linecount_1(  ):
#    return len(open('nuc').readlines(  ))

def join_strs_better(strs):
    return ' '.join(strs)
    

def mapcount(filename):
    f = open(filename, "r+")
    buf = mmap.mmap(f.fileno(), 0)
    lines = 0
    readline = buf.readline
    while readline():
        lines += 1
    return lines

def simplecount(filename):
    lines = 0
    for line in open(filename):
        lines += 1
    return lines

def bufcount(filename):
    f = open(filename)                  
    lines = 0
    buf_size = 1024 * 1024
    read_f = f.read # loop optimization

    buf = read_f(buf_size)
    while buf:
        lines += buf.count('\n')
        buf = read_f(buf_size)

    return lines

def opcount(fname):
    with open(fname) as f:
        for i, l in enumerate(f):
            pass
    return i + 1
    
# Returns True if End-Of-File is reached
def EOF1(f):
    current_pos = f.tell()
    file_size = os.fstat(f.fileno()).st_size
    return current_pos >= file_size
    
def strToList(st):
    return list(st.split("  "))
    
    
pdir=''.join([os.getcwd(),"/DebianISO/install_ext/install/pii2.sh"]);
#print(pdir);
##
# "x" - Create - will create a file, returns an error if the file exist
# "r" - Read - Default value. Opens a file for reading, error if the file does not exist
# "a" - Append - Opens a file for appending, creates the file if it does not exist
# "w" - Write - Opens a file for writing, creates the file if it does not exist
# "x" - Create - Creates the specified file, returns an error if the file exists
# In addition you can specify if the file should be handled as binary or text mode
# "t" - Text - Default value. Text mode
if not (os.path.exists(pdir)):
    print("The file does not exist");
    exit;

with open(pdir,"rt") as fpii2:
    linep = fpii2.readlines();
fpii2.close();
j=0;
if(str(''.join(re.findall('^#!\/bin\/(.*).*', linep[j])).strip())=="bash"):
        print("bash!")
else:
        print("Error: Unknown shell!")
j=1;k=0;
content=[""]*int(len(linep)/6);
#for k in range(0,len(linep)): content[0]="";
#h1
#==================

#h2
#------------------

#h3
#~~~~~~~~~~~~~~~~~~

#h4
""""""""""""""""""

for i in linep:
    #linep[j] = re.sub('\n', '', linep[j])
    if ((''.join(re.findall("^#", linep[j])))=="#"):
        s0=''.join(re.findall("#\t\t\t(\d+\t+[a-zA-Z/_\-&><=$%\[\]* ]*)", linep[j]));
        s1=''.join(re.findall("#\t\t\t(\d.\d+\t+[a-zA-Z/_\-&><=$%\[\]* ]*)", linep[j]));
        s2=''.join(re.findall("#\t\t\t(\d.\d.\d+\t+[a-zA-Z/_\-&><=$%\[\]* ]*)", linep[j]));
    if(s0!=""):
        h1=''.join(['=']*len(s0));
        content[k] = strToList("{0}\n{1}\n".format(s0,h1));
        #print(str(["="]*len(h1)));
        #content[k+1] = strToList("{0}\n".format(''.join(h1)));
        k+=1;
    if(s1!=""):
        h2=''.join(['-']*len(s1));
        content[k] = strToList("\t{0}\n{1}\n".format(s1,h2));
        #print(str(["-"]*len(h2)));
        #content[k+1] = strToList("{0}\n".format(''.join(h2)));
        k+=1;
    if(s2!=""):
        h3=''.join(["~"]*len(s2));
        content[k] = strToList("\t\t{0}\n{1}\n".format(s2,h3));
        k+=1;
        
    linep[j] = re.sub('#<--!|#!-->', '', linep[j]);
    #if (''.join(re.findall("#\t\t\t(\d.\d.\d\.+.*)$", linep[j]))!=""):
    #print(''.join(re.findall("#\t\t\t\d.\d.(\d.\d.+.*)", linep[j])));
    j+=1;
    if(j>=len(linep)):
        break;
#print(re.sub("\t", " ",linep[j]));
#        print("yes");
print("_______________")
print("_______________")
#print(re.findall("#\t\t\t(\d.\d+\t+[a-zA-Z/_\-& ]*)", linep[20]))
#print(re.findall("#\t\t\t(\d.\d.\d+\t+[a-zA-Z/_\-& ]*)", linep[193]))
#str = re.findall("#\t\t\t(.*)$", linep[22])
#str1 = re.sub("\t", " ",linep[22])
#print(content)
print(content)

j=0;
pdir=''.join([os.getcwd(),"/out_content.sh"]);
with open(pdir,"wt") as fpii2:
    for i in content:
        #s0=''.join(content[j]);
        fpii2.write(''.join(content[j]));
        #print(content[j])
        j=j+1;
fpii2.close();

